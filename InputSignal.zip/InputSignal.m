% Specify the path to your CSV file
filename = 'ECG1-CSV.csv';

% Load the data from the CSV file
data = csvread(filename);

% Assuming the signal is in the first row (adjust if it's in a different row or column)
signal = data(1,:);

% Create a time vector assuming a sample rate, adjust 'sampleRate' as needed
sampleRate = 800; % Example sample rate in Hz
time = (0:length(signal)-1) / sampleRate;

% Design a low-pass filter to cut off frequencies above 160 Hz
lpFilt = designfilt('lowpassfir', 'PassbandFrequency', 150, 'StopbandFrequency', 170, 'PassbandRipple', 1, 'StopbandAttenuation', 60, 'SampleRate', sampleRate);

% Apply the filter to the signal
filteredSignal = filtfilt(lpFilt, signal);

% Plot the original signal FFT
figure;
subplot(3,1,1);
fftOriginal = fft(signal);
fftMagOriginal = abs(fftOriginal(1:ceil(length(fftOriginal)/2)));
fOriginal = (0:length(fftMagOriginal)-1)*(sampleRate/length(signal));
plot(fOriginal, fftMagOriginal);
title('Magnitude of FFT of the Original Signal');
xlabel('Frequency (Hz)');
ylabel('|Magnitude|');
grid on;
xlim([0, 200]);

% Plot the FFT of the filtered signal
subplot(3,1,2);
fftFiltered = fft(filteredSignal);
fftMagFiltered = abs(fftFiltered(1:ceil(length(fftFiltered)/2)));
fFiltered = (0:length(fftMagFiltered)-1)*(sampleRate/length(filteredSignal));
plot(fFiltered, fftMagFiltered);
title('Magnitude of FFT of the Filtered Signal');
xlabel('Frequency (Hz)');
ylabel('|Magnitude|');
grid on;
xlim([0, 200]);

% Plot the filtered signal in the time domain
subplot(3,1,3);
plot(time, filteredSignal);
title('Filtered Signal in Time Domain');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;
xlim([time(1), time(end)]);

% Adjusting the figure's layout for better visibility
set(gcf, 'Position', get(0, 'Screensize')); % Optional: makes the figure fullscreen for better visibility
