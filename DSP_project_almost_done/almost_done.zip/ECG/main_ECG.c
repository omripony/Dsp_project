
#ifdef USE_BIOS

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/cfg/global.h>

/* BIOS Header files */

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Swi.h>
#include <ti/sysbios/knl/Semaphore.h>
#endif /* #ifdef USE_BIOS */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>


/* TI-RTOS Header files */
#include <ti/drv/gpio/GPIO.h>
#include <ti/drv/gpio/soc/GPIO_soc.h>

#include <ti/board/board.h>
#include <ti/csl/csl_clec.h>

#include "GPIO_log.h"
#include "GPIO_board.h"
#include "ECG-Signal.h"
#include "fdacoefs.h"

//#define N 1788       //Size array
//#define fs 800      //Sampling freq.

float Threshold= 1;  // Threshold for peak detection

void Board_initGPIO();
void timer0_ISR(void);  //HW interrupt function
void swi0_ISR(void);    //SW interrupt function

//iir filters
void IIR_Biquad();      //lpf
void IIR_Biquad_notch();//
void IIR_Biquad_HPF();//
void digital_filter();  // Envelope detector
void IIR_Biquad_LPF_AFTER_ENVELOPE();//lpf after envelope detector
void peak_count();
void time_peaks();

int idx = 0;                     // Index of the ECG_signal array
float LPF_filter_arr[N]={0};
float notch_filter_arr[N]={0};
float HPF_filter_arr[N]={0};
float abs_arr[N] = {0};          // The signal after passing the full wave rectifier
float abs_arr_envelope[N] = {0};
float filtered_arr[N] = {0};     // Filtered signal array after passing the envalope detector
float IIR_filtered_arr[N] = {0}; // The signal after passing through the IIR filter

//swi0_ISR//
float sample = 0;            // Save the ECG_signal sample
int sample_cnt = 0;          // Count until ? samples (1 second) and than resets

//IIR_Biquad LPF coef//
float d01 = 0, d02 = 0, d00 = 0;
float xn=0, y0 = 0;
float prod1, prod2, prod3, prod4, prod5;

float d01_1 = 0, d02_1 = 0, d00_1 = 0;
float xn_1=0, y0_1 = 0;
float prod1_1, prod2_1, prod3_1, prod4_1, prod5_1;

float d01_2 = 0, d02_2 = 0, d00_2 = 0;
float xn_2=0, y0_2 = 0;
float prod1_2, prod2_2, prod3_2, prod4_2, prod5_2;

float d01_3 = 0, d02_3 = 0, d00_3 = 0;
float xn_3=0, y0_3 = 0;
float prod1_3, prod2_3, prod3_3, prod4_3, prod5_3;

//IIR_Biquad NOTCH coef//

float d01_4 = 0, d02_4 = 0, d00_4 = 0;
float xn_4=0, y0_4 = 0;
float prod1_4, prod2_4, prod3_4, prod4_4, prod5_4;

float d01_5 = 0, d02_5 = 0, d00_5 = 0;
float xn_5=0, y0_5 = 0;
float prod1_5, prod2_5, prod3_5, prod4_5, prod5_5;

float d01_6 = 0, d02_6 = 0, d00_6 = 0;
float xn_6=0, y0_6 = 0;
float prod1_6, prod2_6, prod3_6, prod4_6, prod5_6;

//IIR_Biquad HPF coef//

float d01_7 = 0, d02_7 = 0, d00_7 = 0;
float xn_7=0, y0_7 = 0;
float prod1_7, prod2_7, prod3_7, prod4_7, prod5_7;

float d01_8 = 0, d02_8 = 0, d00_8 = 0;
float xn_8=0, y0_8 = 0;
float prod1_8, prod2_8, prod3_8, prod4_8, prod5_8;

float d01_9 = 0, d02_9 = 0, d00_9 = 0;
float xn_9=0, y0_9 = 0;
float prod1_9, prod2_9, prod3_9, prod4_9, prod5_9;

//LPF coef of envelope detector

float d01_A = 0, d02_A = 0, d00_A = 0;
float xn_A = 0, y0_A = 0;
float prod1_A, prod2_A, prod3_A, prod4_A, prod5_A;

float d01_1_A = 0, d02_1_A = 0, d00_1_A = 0;
float xn_1_A = 0, y0_1_A = 0;
float prod1_1_A, prod2_1_A, prod3_1_A, prod4_1_A, prod5_1_A;

float d01_2_A = 0, d02_2_A = 0, d00_2_A = 0;
float xn_2_A = 0, y0_2_A = 0;
float prod1_2_A, prod2_2_A, prod3_2_A, prod4_2_A, prod5_2_A;

float d01_3_A = 0, d02_3_A = 0, d00_3_A = 0;
float xn_3_A = 0, y0_3_A = 0;
float prod1_3_A, prod2_3_A, prod3_3_A, prod4_3_A, prod5_3_A;


//peak_count//
float bps = 0;              // Saves the heart Beat rate in bps (beat per second)
int flag = 0;               // Manage that every peak gets one index

//time_peaks//
int peak_idx = 0;             // Saves the current peak index
int prev_peak_idx = 0;        // Saves the previous peak index
int second_prev_peak_idx = 0; // Saves the previous previous peak index
int s1_delta = 0;             // Saves the delta time value between s1 and s1 peaks
int s2_delta=0;
int s12_delta = 0;            // Saves the delta time value between s1 and s2 peaks
int prev_s1_delta  = 0;  // Saves the previous delta time value between s1 and s1 peaks
int prev_s2_delta=0;
int prev_s12_delta = 0; // Saves the previous delta time value between s1 and s2 peaks
int peak_cnt = 0;       // Recognizing the type of peak (s1 or s2)

//digital_filter//
float num = 0.115;                /* Constant for negative slope using in envelope detector
                                (capacitor discharge through a resistor) */
int divider_factor=1;
int main(void)
{
    /* Call board init functions */
    Board_initGPIO();
    GPIO_init();

    /* Start BIOS */
    BIOS_start();

    return (0);
}


void Board_initGPIO()
{
    Board_initCfg boardCfg;

    GPIO_v0_HwAttrs gpio_cfg;

    /* Get the default SPI init configurations */
    GPIO_socGetInitCfg(GPIO_LED0_PORT_NUM, &gpio_cfg);


    /* Setup GPIO interrupt configurations */
    GPIO_socSetBankInt(GPIO_LED0_PORT_NUM, GPIO_LED0_PIN_NUM, NULL);
    GPIO_write((USER_LED0), GPIO_PIN_VAL_LOW);

    boardCfg = BOARD_INIT_PINMUX_CONFIG |
    BOARD_INIT_MODULE_CLOCK |
    BOARD_INIT_UART_STDIO;

    Board_init(boardCfg);

}

//Task
void ECG_FILTER(UArg arg0, UArg arg1)
{
    while(1)
    {
        //Pending semaphore
        Semaphore_pend(semaphore0, BIOS_WAIT_FOREVER);  //Wait for sample
        IIR_Biquad();//Filtering the sample-lpf
        IIR_Biquad_notch();//Filtering the sample-notch
        IIR_Biquad_HPF();//Filtering the sample-hpf
              //Absolute array's values

        //abs_arr[idx] =  filtered_arr[idx];

        // Envelope detector
        if (idx > 0)
            digital_filter();

        if(idx == N)  // Zeroing indexes when the array is full
        {
            idx = 0;
        }


        else
            idx++;
    }
}

// Sampling ISR according to fs frequency (800Hz)
void timer0_ISR(void)
{
    Swi_post(swi0);     //SW interrupt post
}

// Getting the ECG_signal sample
void swi0_ISR(void)
{
    // samples ECG signal
    sample = ECG_signal[idx];
    sample_cnt ++;

    Semaphore_post(semaphore0); //post semaphore
}
//////////////////////////////////////ALL THE BIQUADS FILTER/////////////////////////////
void IIR_Biquad()
{
    // Clean IIR every time the buffer is fulfilled
    if (idx == 0 )
    {
        d00 = 0;
        d01 = 0;
        d02 = 0;

        d00_1 = 0;
        d01_1 = 0;
        d02_1 = 0;

        d00_2 = 0;
        d01_2 = 0;
        d02_2 = 0;

        d00_3 = 0;
        d01_3 = 0;
        d02_3 = 0;


    }

    // section 1--- Read the input sample from the signal buffer -- level zero
    xn = sample;
    y0 = 0;
    prod1 = d02*DEN[1][2];
    prod2 = d01*DEN[1][1];
    d00 = xn - prod1 - prod2;
    prod3 = d01*NUM[1][1];
    prod4 = d02*NUM[1][2];
    prod5 = d00*NUM[1][0];
    y0 = prod3+prod4+prod5;
    d02 = d01;
    d01 = d00;

    //  section 2                                  -- level 1
    xn_1 = y0*NUM[0][0];
    y0_1 = 0;
    prod1_1 = d02_1*DEN[3][2];
    prod2_1 = d01_1*DEN[3][1];
    d00_1 = xn_1 - prod1_1 - prod2_1;
    prod3_1 = d01_1*NUM[3][1];
    prod4_1 = d02_1*NUM[3][2];
    prod5_1 = d00_1*NUM[3][0];
    y0_1 = prod3_1+prod4_1+prod5_1;
    d02_1 = d01_1;
    d01_1 = d00_1;

    // section 3                                     -- level 2
    xn_2 = y0_1*NUM[2][0];
    y0_2 = 0;
    prod1_2 = d02_2*DEN[5][2];
    prod2_2 = d01_2*DEN[5][1];
    d00_2 = xn_2 - prod1_2 - prod2_2;
    prod3_2 = d01_2*NUM[5][1];
    prod4_2 = d02_2*NUM[5][2];
    prod5_2 = d00_2*NUM[5][0];
    y0_2 = prod3_2 + prod4_2 + prod5_2;
    d02_2 = d01_2;
    d01_2 = d00_2;

    // section 4                                    -- level 3
    xn_3 = y0_2*NUM[4][0];
    y0_3 = 0;
    prod1_3 = d02_3*DEN[7][2];
    prod2_3 = d01_3*DEN[7][1];
    d00_3 = xn_3 - prod1_3 - prod2_3;
    prod3_3 = d01_3*NUM[7][1];
    prod4_3 = d02_3*NUM[7][2];
    prod5_3 = d00_3*NUM[7][0];
    y0_3 = prod3_3 + prod4_3 + prod5_3;
    d02_3 = d01_3;
    d01_3 = d00_3;
    LPF_filter_arr[idx] = y0_3*NUM[6][0];


}
void IIR_Biquad_notch()
{
    // Clean IIR every time the buffer is fulfilled
    if (idx == 0 )
    {
       d00_4 = 0;
       d01_4 = 0;
       d02_4 = 0;

       d00_5 = 0;
       d01_5 = 0;
       d02_5 = 0;

       d00_6 = 0;
       d01_6 = 0;
       d02_6 = 0;

    }

    // section 1--- Read the input sample from the signal buffer -- level zero

        xn_4 = LPF_filter_arr[idx]*NUM[8][0];  //for cascading the notch filter get as input the lpf filter output
        //xn_4 = sample*NUM[8][0];  // for testing the notch only!
        y0_4 = 0;
        prod1_4 = d02_4*DEN_notch[1][2];
        prod2_4 = d01_4*DEN_notch[1][1];
        d00_4 = xn_4 - prod1_4 - prod2_4;
        prod3_4 = d01_4*NUM_notch[1][1];
        prod4_4 = d02_4*NUM_notch[1][2];
        prod5_4 = d00_4*NUM_notch[1][0];
        y0_4 = prod3_4+prod4_4+prod5_4;
        d02_4 = d01_4;
        d01_4 = d00_4;

        //  section 2                                  -- level 1
        xn_5 = y0_4*NUM_notch[0][0];
        y0_5 = 0;
        prod1_5 = d02_5*DEN_notch[3][2];
        prod2_5 = d01_5*DEN_notch[3][1];
        d00_5 = xn_5 - prod1_5 - prod2_5;
        prod3_5 = d01_5*NUM_notch[3][1];
        prod4_5 = d02_5*NUM_notch[3][2];
        prod5_5 = d00_5*NUM_notch[3][0];
        y0_5 = prod3_5+prod4_5+prod5_5;
        d02_5 = d01_5;
        d01_5 = d00_5;

        // section 3                                     -- level 2
        xn_6 = y0_5*NUM_notch[2][0];
        y0_6 = 0;
        prod1_6 = d02_6*DEN_notch[5][2];
        prod2_6 = d01_6*DEN_notch[5][1];
        d00_6 = xn_6 - prod1_6 - prod2_6;
        prod3_6 = d01_6*NUM_notch[5][1];
        prod4_6 = d02_6*NUM_notch[5][2];
        prod5_6 = d00_6*NUM_notch[5][0];
        y0_6 = prod3_6 + prod4_6 + prod5_6;
        d02_6 = d01_6;
        d01_6 = d00_6;

        // The signal after the IIR filter//
        notch_filter_arr[idx] = y0_6*NUM_notch[6][0];

}

void IIR_Biquad_HPF()
{
    // Clean IIR every time the buffer is fulfilled
    if (idx == 0 )
    {
       d00_7 = 0;
       d01_7 = 0;
       d02_7 = 0;

       d00_8 = 0;
       d01_8 = 0;
       d02_8 = 0;

       d00_9 = 0;
       d01_9 = 0;
       d02_9 = 0;

    }

    // section 1--- Read the input sample from the signal buffer -- level zero

       // xn_7 = sample*NUM_notch[6][0]; //for testing the HPF only
        xn_7 = notch_filter_arr[idx]*NUM_notch[6][0];
        y0_7 = 0;
        prod1_7 = d02_7*DEN_HPF[1][2];
        prod2_7 = d01_7*DEN_HPF[1][1];
        d00_7 = xn_7 - prod1_7 - prod2_7;
        prod3_7 = d01_7*NUM_HPF[1][1];
        prod4_7 = d02_7*NUM_HPF[1][2];
        prod5_7 = d00_7*NUM_HPF[1][0];
        y0_7 = prod3_7+prod4_7+prod5_7;
        d02_7 = d01_7;
        d01_7 = d00_7;

        //  section 2                                  -- level 1
        xn_8 = y0_7*NUM_HPF[0][0];
        y0_8 = 0;
        prod1_8 = d02_8*DEN_HPF[3][2];
        prod2_8 = d01_8*DEN_HPF[3][1];
        d00_8 = xn_8 - prod1_8 - prod2_8;
        prod3_8 = d01_8*NUM_HPF[3][1];
        prod4_8 = d02_8*NUM_HPF[3][2];
        prod5_8 = d00_8*NUM_HPF[3][0];
        y0_8 = prod3_8+prod4_8+prod5_8;
        d02_8 = d01_8;
        d01_8 = d00_8;

        // section 3                                     -- level 2
        xn_9 = y0_8*NUM_HPF[2][0];
        y0_9 = 0;
        prod1_9 = d02_9*DEN_HPF[5][2];
        prod2_9 = d01_9*DEN_HPF[5][1];
        d00_9 = xn_9 - prod1_9 - prod2_9;
        prod3_9 = d01_9*NUM_HPF[5][1];
        prod4_9 = d02_9*NUM_HPF[5][2];
        prod5_9 = d00_9*NUM_HPF[5][0];
        y0_9 = prod3_9 + prod4_9 + prod5_9;
        d02_9 = d01_9;
        d01_9 = d00_9;

        // The signal after the IIR filter
        HPF_filter_arr[idx] = y0_9*NUM_HPF[6][0];
        //envelope detector processoring

        abs_arr[idx] = sqrt(pow( HPF_filter_arr[idx],2));//after "diode"


        abs_arr_envelope[idx] = abs_arr[idx];
        if (idx)
        {
            if(abs_arr_envelope[idx] < abs_arr_envelope[idx - 1])//"rectifier" function
            {
                if((abs_arr_envelope[idx - 1] - num)>0)
                    abs_arr_envelope[idx] = abs_arr_envelope[idx - 1] - num;
                else
                    abs_arr_envelope[idx]=(abs_arr_envelope[idx - 1]-abs_arr_envelope[idx])/divider_factor;
            }

        }

        filtered_arr[idx]=abs_arr_envelope[idx];
        peak_count();

//        IIR_Biquad_LPF_AFTER_ENVELOPE();
//        peak_count();

}

/* Create constant negative slope using in envelope detector
(capacitor discharge through a resistor) */
void digital_filter()
{
    if(filtered_arr[idx] < filtered_arr[idx - 1])
        filtered_arr[idx] = filtered_arr[idx - 1] - num;
}

void IIR_Biquad_LPF_AFTER_ENVELOPE()
{
    // Clean IIR every time the buffer is fulfilled
    if (idx == 0 )
    {
        d00_A = 0;
        d01_A = 0;
        d02_A = 0;

        d00_1_A = 0;
        d01_1_A = 0;
        d02_1_A = 0;

        d00_2_A = 0;
        d01_2_A = 0;
        d02_2_A = 0;

        d00_3_A = 0;
        d01_3_A = 0;
        d02_3_A = 0;
    }

    // section 1--- Read the input sample from the signal buffer -- level zero
    xn_A =  abs_arr_envelope[idx];
    y0_A = 0;
    prod1_A = d02_A * DEN_A[1][2];
    prod2_A = d01_A * DEN_A[1][1];
    d00_A = xn_A - prod1_A - prod2_A;
    prod3_A = d01_A * NUM_A[1][1];
    prod4_A = d02_A * NUM_A[1][2];
    prod5_A = d00_A * NUM_A[1][0];
    y0_A = prod3_A + prod4_A + prod5_A;
    d02_A = d01_A;
    d01_A = d00_A;

    //  section 2                                  -- level 1
    xn_1_A = y0_A * NUM_A[0][0];
    y0_1_A = 0;
    prod1_1_A = d02_1_A * DEN_A[3][2];
    prod2_1_A = d01_1_A * DEN_A[3][1];
    d00_1_A = xn_1_A - prod1_1_A - prod2_1_A;
    prod3_1_A = d01_1_A * NUM_A[3][1];
    prod4_1_A = d02_1_A * NUM_A[3][2];
    prod5_1_A = d00_1_A * NUM_A[3][0];
    y0_1_A = prod3_1_A + prod4_1_A + prod5_1_A;
    d02_1_A = d01_1_A;
    d01_1_A = d00_1_A;

    // section 3                                     -- level 2
    xn_2_A = y0_1_A * NUM_A[2][0];
    y0_2_A = 0;
    prod1_2_A = d02_2_A * DEN_A[5][2];
    prod2_2_A = d01_2_A * DEN_A[5][1];
    d00_2_A = xn_2_A - prod1_2_A - prod2_2_A;
    prod3_2_A = d01_2_A * NUM_A[5][1];
    prod4_2_A = d02_2_A * NUM_A[5][2];
    prod5_2_A = d00_2_A * NUM_A[5][0];
    y0_2_A = prod3_2_A + prod4_2_A + prod5_2_A;
    d02_2_A = d01_2_A;
    d01_2_A = d00_2_A;


    // section 4                                    -- level 3
    abs_arr_envelope[idx]= y0_2_A * NUM_A[4][0];
    filtered_arr[idx]=abs_arr_envelope[idx];

}


// Count s1 and s2 peaks
void peak_count()
{
    // Detect rising and falling of every peak
    if ((filtered_arr[idx] > Threshold && flag == 0)&&(filtered_arr[idx]>filtered_arr[idx-1])&&(filtered_arr[idx]>filtered_arr[idx+1]))
    {
        peak_cnt++;                // Increase the current index of the peak
        prev_peak_idx = peak_idx;  // Save the previous peak index
        peak_idx = idx;            // Update the current peak index
        flag = 1;                  // Make sure the peak is measured only once
    }
    else if (filtered_arr[idx] < Threshold)
        flag = 0;

    if (sample_cnt == 800)  //800 counts in every second for fs = 800[Hz]
    {
        sample_cnt = 0;      // After crossing one second, reset the counter
        time_peaks();        // Call the time measure function
    }
}
// Calculate the delta time between two peaks (s1-s1 and s1-s2)
void time_peaks()
{
    int prev_delta=abs(prev_s1_delta-prev_s2_delta);
    prev_s1_delta = s1_delta;
    prev_s2_delta = s2_delta;


    if (peak_cnt % 2 && peak_cnt > 2) // Calculate the delta time for primary peaks (S1-S1)
    {

        s1_delta = abs(peak_idx - second_prev_peak_idx); //peak_idx minus peak_idx-2

        bps = (float)(800.0 / s1_delta);            // Calculate the heart rate in beat per second format
        if ((s1_delta != prev_s1_delta)&&(s1_delta<=1.2*prev_delta)&&(s1_delta>=0.8*prev_delta))
        {
            System_printf("previous s1 peak index = %d current s1 peak index = %d\n", second_prev_peak_idx, peak_idx);
            System_printf("s1_delta = %d [0.5msec]\n", s1_delta);
            System_printf("Heart rate = %f bpm\n", bps * 60);
            System_flush();
        }
    }
    else if (((peak_cnt % 2) == 0) && peak_cnt > 1) // Calculate the delta time for secondary peaks (S1-S2)
    {
        int temp_prev_peak_idx=second_prev_peak_idx;
        second_prev_peak_idx = prev_peak_idx; // Save the peak_idx-2 index
        s12_delta = abs(peak_idx - prev_peak_idx); //peak_idx minus peak_idx-1
        if ((s12_delta != prev_s2_delta)&&(temp_prev_peak_idx<=1.2*s12_delta)&&(temp_prev_peak_idx>=0.8*s12_delta))
        {
            System_printf("s1 peak index = %d s2 peak index = %d\n", second_prev_peak_idx, peak_idx);
            System_printf("s12_delta = %d [0.5msec]\n", s12_delta);
            System_flush();
        }
    }
}
