/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-K04
 */

#ifndef xconfig_UIA_StopMode_Template__
#define xconfig_UIA_StopMode_Template__



#endif /* xconfig_UIA_StopMode_Template__ */ 
