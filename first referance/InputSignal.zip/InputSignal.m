% Specify the path to your CSV file
filename = 'ECG1-CSV.csv';

% Load the data from the CSV file
data = csvread(filename);

% Assuming the signal is in the first row (adjust if it's in a different row or column)
signal = data(1,:);

% Create a time vector assuming a sample rate, adjust 'sampleRate' as needed
sampleRate = 800; % Example sample rate in Hz
time = (0:length(signal)-1) / sampleRate;

% Plot the original signal in the first subplot
figure;
subplot(2,1,1); % Creates a subplot grid of 2 rows, 1 column, and selects the 1st subplot for the current plot
plot(time, signal);
title('Original Noisy Signal');
xlabel('Time (seconds)');
ylabel('Amplitude');
grid on;
xlim([time(1), time(end)]); % Set x-axis limits to the range of time

% Apply FFT to the signal
fftSignal = fft(signal);
% Calculate the magnitude of the FFT
fftMag = abs(fftSignal);
% Only half of the FFT output is needed (symmetrical)
fftMag = fftMag(1:ceil(length(fftMag)/2));

% Generate the frequency vector for the positive frequencies
N = length(signal); % Number of points in FFT
f = (0:N-1)*(sampleRate/N); % Frequency range
f = f(1:ceil(length(f)/2)); % Only half is needed

% Find the index corresponding to 200 Hz
index200Hz = find(f <= 200, 1, 'last');

% Plot the magnitude of the FFT in the second subplot, up to 200 Hz
subplot(2,1,2); % Selects the 2nd subplot for the current plot
plot(f(1:index200Hz), fftMag(1:index200Hz));
title('Magnitude of FFT of the Signal (Up to 200 Hz)');
xlabel('Frequency (Hz)');
ylabel('|Magnitude|');
grid on;
xlim([0, 200]); % Limits the x-axis to 200 Hz for clarity

% Adjusting the figure's layout for better visibility
set(gcf, 'Position', get(0, 'Screensize')); % Optional: makes the figure fullscreen for better visibility
